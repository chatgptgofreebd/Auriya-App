#!/bin/bash
# ==============================================================================
# AURIYA AI — Next-Generation Personal AI Assistant
# Environment Setup Script for Termux & Linux
# ==============================================================================

set -e

echo "=========================================================="
echo "   [AURIYA AI] Initializing Environment Setup"
echo "   Tagline: Your World. Your Intelligence. Your AURIYA."
echo "=========================================================="

# Check if running in Termux
if [ -d "/data/data/com.termux" ]; then
    IS_TERMUX=true
    echo "[+] Termux environment detected."
else
    IS_TERMUX=false
    echo "[+] Standard Linux/Desktop environment detected."
fi

echo "[*] Checking essential build tools..."

# Check Java
if command -v java >/dev/null 2>&1; then
    JAVA_VERSION=$(java -version 2>&1 | head -n 1)
    echo "[✓] Java is installed: $JAVA_VERSION"
else
    echo "[!] Java is not found."
    if [ "$IS_TERMUX" = true ]; then
        echo "[*] Installing OpenJDK 17 in Termux..."
        pkg update -y && pkg install openjdk-17 -y
    else
        echo "[!] Please install JDK 17 or higher (e.g., sudo apt install openjdk-17-jdk)"
        exit 1
    fi
fi

# Check Zip
if command -v zip >/dev/null 2>&1; then
    echo "[✓] zip utility found."
else
    echo "[*] Installing zip utility..."
    if [ "$IS_TERMUX" = true ]; then
        pkg install zip unzip -y
    fi
fi

# Ensure executable permissions
chmod +x gradlew 2>/dev/null || true
chmod +x build.sh 2>/dev/null || true
chmod +x install.sh 2>/dev/null || true

# Prepare output directory
mkdir -p output

echo "=========================================================="
echo "   [✓] Setup Complete! Run 'bash build.sh' to build APK."
echo "=========================================================="
