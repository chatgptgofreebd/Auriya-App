#!/bin/bash
# ==============================================================================
# AURIYA AI — Next-Generation Personal AI Assistant
# Automatic Build System for Android & Termux
# ==============================================================================

set -e

PROJECT_NAME="AURIYA AI"
OUTPUT_DIR="output"
FINAL_APK="$OUTPUT_DIR/AURIYA-AI.apk"
FINAL_ZIP="$OUTPUT_DIR/AURIYA-AI-Full-Source.zip"

echo "=========================================================="
echo "   BUILD SYSTEM: $PROJECT_NAME"
echo "   Tagline: Your World. Your Intelligence. Your AURIYA."
echo "=========================================================="

mkdir -p "$OUTPUT_DIR"

# Stage 1: Dependency Verification
echo "[Stage 1/4] Verifying Build Prerequisites..."

MISSING_DEPS=()

if ! command -v java >/dev/null 2>&1; then
    MISSING_DEPS+=("Java JDK 17+")
fi

if ! command -v gradle >/dev/null 2>&1 && [ ! -f "./gradlew" ]; then
    MISSING_DEPS+=("Gradle")
fi

if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
    echo "[!] ERROR: Missing required build dependencies:"
    for dep in "${MISSING_DEPS[@]}"; do
        echo "    - $dep"
    done
    echo ""
    echo "Setup Instructions:"
    echo "  In Termux: run 'bash setup.sh' or 'pkg install openjdk-17 -y'"
    echo "  In Linux:  run 'sudo apt install openjdk-17-jdk -y'"
    exit 1
fi

echo "[✓] All build tools detected."

# Stage 2: Compilation & APK Generation
echo "[Stage 2/4] Compiling $PROJECT_NAME Android APK..."

BUILD_CMD=""
if command -v gradle >/dev/null 2>&1; then
    BUILD_CMD="gradle"
elif [ -f "./gradlew" ]; then
    chmod +x ./gradlew
    BUILD_CMD="./gradlew"
else
    echo "[!] Neither gradle nor gradlew found."
    exit 1
fi

echo "[*] Running: $BUILD_CMD assembleDebug"
if $BUILD_CMD assembleDebug; then
    echo "[✓] Gradle build completed successfully."
else
    echo "[!] Compilation failed. Please inspect logs above."
    echo "Troubleshooting:"
    echo "  1. Ensure Java 17+ is active (java -version)"
    echo "  2. Ensure ANDROID_SDK_ROOT is set"
    echo "  3. Run 'gradle --stacktrace' for detailed trace"
    exit 1
fi

# Locate generated APK
GENERATED_APK=$(find app/build/outputs/apk/debug -name "*.apk" 2>/dev/null | head -n 1)

if [ -n "$GENERATED_APK" ] && [ -f "$GENERATED_APK" ]; then
    cp "$GENERATED_APK" "$FINAL_APK"
    echo "[✓] Output APK generated: $FINAL_APK"
else
    echo "[!] Warning: Generated APK could not be located in app/build/outputs/apk/debug"
fi

# Stage 3: Source Code Packaging
echo "[Stage 3/4] Packaging Complete Project Source Code..."
if command -v zip >/dev/null 2>&1; then
    rm -f "$FINAL_ZIP"
    zip -r -q "$FINAL_ZIP" . \
        -x "app/build/*" ".gradle/*" "build/*" "output/*" \
        -x "*.keystore" "*.jks"
    echo "[✓] Source archive generated: $FINAL_ZIP"
else
    echo "[!] zip command not found. Skipping zip packaging. Run 'pkg install zip' to enable."
fi

# Stage 4: Build Summary & Verification
echo "=========================================================="
echo "   [✓] BUILD COMPLETE: $PROJECT_NAME"
echo "=========================================================="
echo "Artifacts Generated:"
[ -f "$FINAL_APK" ] && echo "  - APK:    $(pwd)/$FINAL_APK"
[ -f "$FINAL_ZIP" ] && echo "  - Source: $(pwd)/$FINAL_ZIP"
echo "  - Docs:   $(pwd)/README.md"
echo ""
echo "Installation Guide:"
echo "  To install on device: bash install.sh"
echo "=========================================================="
