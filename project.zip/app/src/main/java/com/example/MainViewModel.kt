package com.example

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AuriyaBrain
import com.example.ai.GeminiApiClient
import com.example.ai.GeminiGenerationConfig
import com.example.coding.CodeStudioEngine
import com.example.data.local.AppDatabase
import com.example.data.local.AutomationEntity
import com.example.data.local.CodeProjectEntity
import com.example.data.local.ConversationEntity
import com.example.data.local.MemoryEntity
import com.example.device.DeviceController
import com.example.model.ActionType
import com.example.model.AssistantLanguage
import com.example.model.ChatMessage
import com.example.model.CodeLanguage
import com.example.model.CodeProject
import com.example.model.DeviceStatus
import com.example.model.MessageRole
import com.example.model.PersonalityMode
import com.example.voice.AuriyaVoiceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

enum class NavigationTab(val title: String) {
    HOME("Core"),
    CHAT("Auriya Chat"),
    CODING("Code Studio"),
    AUTOMATIONS("Automations"),
    MEMORY("Memory"),
    SETTINGS("Settings")
}

enum class AssistantStatus {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val deviceController = DeviceController(application)
    val codeStudioEngine = CodeStudioEngine()
    val auriyaBrain = AuriyaBrain()

    private val prefs = application.getSharedPreferences("auriya_prefs", Context.MODE_PRIVATE)

    // Navigation & Status
    private val _currentTab = MutableStateFlow(NavigationTab.HOME)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    private val _assistantStatus = MutableStateFlow(AssistantStatus.IDLE)
    val assistantStatus: StateFlow<AssistantStatus> = _assistantStatus.asStateFlow()

    private val _deviceStatus = MutableStateFlow(deviceController.getDeviceStatus())
    val deviceStatus: StateFlow<DeviceStatus> = _deviceStatus.asStateFlow()

    // Configurable Settings
    private val _personality = MutableStateFlow(
        PersonalityMode.valueOf(prefs.getString("personality", PersonalityMode.EMPATHETIC_ASSISTANT.name) ?: PersonalityMode.EMPATHETIC_ASSISTANT.name)
    )
    val personality: StateFlow<PersonalityMode> = _personality.asStateFlow()

    private val _language = MutableStateFlow(
        AssistantLanguage.valueOf(prefs.getString("language", AssistantLanguage.ENGLISH.name) ?: AssistantLanguage.ENGLISH.name)
    )
    val language: StateFlow<AssistantLanguage> = _language.asStateFlow()

    private val _selectedModel = MutableStateFlow(
        prefs.getString("selected_model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    )
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _customApiKey = MutableStateFlow(prefs.getString("custom_api_key", "") ?: "")
    val customApiKey: StateFlow<String> = _customApiKey.asStateFlow()

    private val _temperature = MutableStateFlow(prefs.getFloat("temperature", 0.7f))
    val temperature: StateFlow<Float> = _temperature.asStateFlow()

    private val _voicePitch = MutableStateFlow(prefs.getFloat("voice_pitch", 1.15f))
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()

    private val _voiceRate = MutableStateFlow(prefs.getFloat("voice_rate", 1.0f))
    val voiceRate: StateFlow<Float> = _voiceRate.asStateFlow()

    private val _voiceResponsesEnabled = MutableStateFlow(prefs.getBoolean("voice_enabled", true))
    val voiceResponsesEnabled: StateFlow<Boolean> = _voiceResponsesEnabled.asStateFlow()

    // Active Code Project
    private val _activeProject = MutableStateFlow<CodeProject?>(null)
    val activeProject: StateFlow<CodeProject?> = _activeProject.asStateFlow()

    // Voice Engine
    val voiceEngine = AuriyaVoiceEngine(application) { spokenText ->
        viewModelScope.launch(Dispatchers.Main) {
            handleUserPrompt(spokenText, null)
        }
    }

    // Database flows
    val chatMessages: StateFlow<List<ChatMessage>> = db.conversationDao().getAllMessages()
        .map { list ->
            list.map { entity ->
                ChatMessage(
                    id = entity.id,
                    role = try { MessageRole.valueOf(entity.role) } catch (_: Exception) { MessageRole.AURIYA },
                    content = entity.content,
                    timestamp = entity.timestamp,
                    actionTag = entity.actionTag,
                    imageUri = entity.imageUri
                )
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories: StateFlow<List<MemoryEntity>> = db.memoryDao().getAllMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val automations: StateFlow<List<AutomationEntity>> = db.automationDao().getAllAutomations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val codeProjects: StateFlow<List<CodeProjectEntity>> = db.codeProjectDao().getAllProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        refreshDeviceStatus()
        voiceEngine.configureTtsLanguage(_language.value)
        voiceEngine.voicePitch = _voicePitch.value
        voiceEngine.voiceRate = _voiceRate.value

        viewModelScope.launch {
            voiceEngine.isListening.collect { listening ->
                if (listening) {
                    _assistantStatus.value = AssistantStatus.LISTENING
                } else if (_assistantStatus.value == AssistantStatus.LISTENING) {
                    _assistantStatus.value = AssistantStatus.IDLE
                }
            }
        }
        viewModelScope.launch {
            voiceEngine.isSpeaking.collect { speaking ->
                if (speaking) {
                    _assistantStatus.value = AssistantStatus.SPEAKING
                } else if (_assistantStatus.value == AssistantStatus.SPEAKING) {
                    _assistantStatus.value = AssistantStatus.IDLE
                }
            }
        }
    }

    fun setTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun refreshDeviceStatus() {
        _deviceStatus.value = deviceController.getDeviceStatus()
    }

    fun getEffectiveApiKey(): String {
        val custom = _customApiKey.value.trim()
        if (custom.isNotBlank()) return custom
        return try {
            val buildConfigKey = BuildConfig.GEMINI_API_KEY
            if (buildConfigKey.isNotBlank() && buildConfigKey != "MY_GEMINI_API_KEY") {
                buildConfigKey
            } else ""
        } catch (_: Exception) {
            ""
        }
    }

    fun handleUserPrompt(text: String, imageBitmap: Bitmap? = null) {
        val trimmed = text.trim()
        if (trimmed.isBlank() && imageBitmap == null) return

        deviceController.triggerHaptic()

        viewModelScope.launch(Dispatchers.IO) {
            // Check memory intent e.g., "remember that..."
            checkAndStoreMemoryIntent(trimmed)

            // Save user message
            db.conversationDao().insertMessage(
                ConversationEntity(
                    role = MessageRole.USER.name,
                    content = trimmed,
                    timestamp = System.currentTimeMillis()
                )
            )

            // Check custom automations first
            val triggeredAutomation = checkCustomAutomations(trimmed)
            if (triggeredAutomation != null) {
                executeAutomationAction(triggeredAutomation)
                return@launch
            }

            _assistantStatus.value = AssistantStatus.THINKING

            // Prepare memory context
            val memoryList = db.memoryDao().getMemoriesSnapshot().map { "${it.key}: ${it.value}" }
            val history = chatMessages.value.takeLast(10).map {
                (if (it.role == MessageRole.USER) "user" else "model") to it.content
            }

            val response = auriyaBrain.processQuery(
                query = trimmed,
                history = history,
                apiKey = getEffectiveApiKey(),
                model = _selectedModel.value,
                personality = _personality.value,
                language = _language.value,
                memories = memoryList,
                deviceStatus = _deviceStatus.value,
                deviceController = deviceController,
                imageBitmap = imageBitmap
            )

            // Insert Auriya response
            db.conversationDao().insertMessage(
                ConversationEntity(
                    role = MessageRole.AURIYA.name,
                    content = response.replyText,
                    timestamp = System.currentTimeMillis(),
                    actionTag = response.executedAction
                )
            )

            _assistantStatus.value = AssistantStatus.IDLE

            // Speak response if voice responses are enabled
            if (_voiceResponsesEnabled.value && response.replyText.isNotBlank()) {
                voiceEngine.speak(response.replyText)
            }
        }
    }

    private suspend fun checkAndStoreMemoryIntent(query: String) {
        val lower = query.lowercase()
        if (lower.startsWith("remember that ") || lower.startsWith("মনে রাখো ") || lower.startsWith("yaad rakhna ")) {
            val fact = query.substringAfter("that ").substringAfter("রাখো ").substringAfter("rakhna ").trim()
            if (fact.isNotBlank()) {
                db.memoryDao().insertMemory(
                    MemoryEntity(
                        key = "User Preference",
                        value = fact,
                        category = "Preference",
                        isUserApproved = true
                    )
                )
            }
        }
    }

    private suspend fun checkCustomAutomations(query: String): AutomationEntity? {
        val enabledList = db.automationDao().getEnabledAutomations()
        val lower = query.lowercase().trim()
        return enabledList.firstOrNull { lower.contains(it.triggerPhrase.lowercase().trim()) }
    }

    private fun executeAutomationAction(auto: AutomationEntity) {
        viewModelScope.launch(Dispatchers.Main) {
            var actionTag: String? = null
            var reply = "Executing automation: ${auto.title}"

            when (auto.actionType) {
                ActionType.LAUNCH_YOUTUBE.name -> {
                    deviceController.launchYouTube(query = auto.actionParam.ifBlank { null })
                    actionTag = "Launched YouTube"
                    reply = "Launching YouTube for you."
                }
                ActionType.PLAY_MUSIC.name -> {
                    deviceController.playMusic(query = auto.actionParam.ifBlank { "chill music" })
                    actionTag = "Played Music"
                    reply = "Playing music as requested."
                }
                ActionType.OPEN_CAMERA.name -> {
                    deviceController.openCamera()
                    actionTag = "Opened Camera"
                    reply = "Launching camera."
                }
                ActionType.OPEN_GALLERY.name -> {
                    deviceController.openGallery()
                    actionTag = "Opened Gallery"
                    reply = "Opening gallery."
                }
                ActionType.BATTERY_STATUS.name -> {
                    val s = deviceController.getDeviceStatus()
                    actionTag = "Checked Battery"
                    reply = "Battery is at ${s.batteryPercent}%, ${if (s.isCharging) "charging." else "on battery."}"
                }
                ActionType.OPEN_SETTINGS.name -> {
                    deviceController.openSettings(auto.actionParam.ifBlank { "general" })
                    actionTag = "Opened Settings"
                    reply = "Opening device settings."
                }
                ActionType.OPEN_CODING_STUDIO.name -> {
                    _currentTab.value = NavigationTab.CODING
                    actionTag = "Code Studio"
                    reply = "Welcome to Auriya Coding Studio."
                }
                else -> {
                    reply = "Completed automation: ${auto.title}"
                }
            }

            viewModelScope.launch(Dispatchers.IO) {
                db.conversationDao().insertMessage(
                    ConversationEntity(
                        role = MessageRole.AURIYA.name,
                        content = reply,
                        timestamp = System.currentTimeMillis(),
                        actionTag = actionTag
                    )
                )
                if (_voiceResponsesEnabled.value) {
                    voiceEngine.speak(reply)
                }
            }
        }
    }

    fun startListening() {
        voiceEngine.startListening()
    }

    fun stopListening() {
        voiceEngine.stopListening()
    }

    fun stopSpeaking() {
        voiceEngine.stopSpeaking()
    }

    fun clearChat() {
        viewModelScope.launch(Dispatchers.IO) {
            db.conversationDao().clearHistory()
        }
    }

    fun addMemory(key: String, value: String, category: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.memoryDao().insertMemory(
                MemoryEntity(key = key, value = value, category = category)
            )
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            db.memoryDao().deleteMemory(memory)
        }
    }

    fun toggleAutomation(auto: AutomationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            db.automationDao().updateAutomation(auto.copy(isEnabled = !auto.isEnabled))
        }
    }

    fun addAutomation(title: String, triggerPhrase: String, actionType: ActionType, actionParam: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.automationDao().insertAutomation(
                AutomationEntity(
                    title = title,
                    triggerPhrase = triggerPhrase,
                    actionType = actionType.name,
                    actionParam = actionParam
                )
            )
        }
    }

    fun deleteAutomation(auto: AutomationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            db.automationDao().deleteAutomation(auto)
        }
    }

    fun selectProject(project: CodeProjectEntity) {
        val lang = try { CodeLanguage.valueOf(project.language) } catch (_: Exception) { CodeLanguage.HTML }
        _activeProject.value = CodeProject(
            id = project.id,
            name = project.name,
            language = lang,
            codeContent = project.codeContent,
            lastUpdated = project.lastUpdated
        )
    }

    fun createProject(name: String, language: CodeLanguage, code: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = db.codeProjectDao().insertProject(
                CodeProjectEntity(
                    name = name,
                    language = language.name,
                    codeContent = code.ifBlank { language.sampleCode }
                )
            )
            _activeProject.value = CodeProject(
                id = id,
                name = name,
                language = language,
                codeContent = code.ifBlank { language.sampleCode }
            )
        }
    }

    fun updateActiveProjectCode(newCode: String) {
        val current = _activeProject.value ?: return
        val updated = current.copy(codeContent = newCode, lastUpdated = System.currentTimeMillis())
        _activeProject.value = updated
        viewModelScope.launch(Dispatchers.IO) {
            db.codeProjectDao().updateProject(
                CodeProjectEntity(
                    id = updated.id,
                    name = updated.name,
                    language = updated.language.name,
                    codeContent = updated.codeContent,
                    lastUpdated = updated.lastUpdated
                )
            )
        }
    }

    fun deleteProject(project: CodeProjectEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            db.codeProjectDao().deleteProject(project)
            if (_activeProject.value?.id == project.id) {
                _activeProject.value = null
            }
        }
    }

    fun exportCurrentProjectZip(context: Context): File? {
        val current = _activeProject.value ?: return null
        return codeStudioEngine.exportProjectToZip(context, current)
    }

    fun setPersonality(mode: PersonalityMode) {
        _personality.value = mode
        prefs.edit().putString("personality", mode.name).apply()
    }

    fun setLanguage(lang: AssistantLanguage) {
        _language.value = lang
        voiceEngine.configureTtsLanguage(lang)
        prefs.edit().putString("language", lang.name).apply()
    }

    fun setModel(model: String) {
        _selectedModel.value = model
        prefs.edit().putString("selected_model", model).apply()
    }

    fun setCustomApiKey(key: String) {
        _customApiKey.value = key
        prefs.edit().putString("custom_api_key", key).apply()
    }

    fun setTemperature(temp: Float) {
        _temperature.value = temp
        prefs.edit().putFloat("temperature", temp).apply()
    }

    fun setVoicePitch(pitch: Float) {
        _voicePitch.value = pitch
        voiceEngine.voicePitch = pitch
        prefs.edit().putFloat("voice_pitch", pitch).apply()
    }

    fun setVoiceRate(rate: Float) {
        _voiceRate.value = rate
        voiceEngine.voiceRate = rate
        prefs.edit().putFloat("voice_rate", rate).apply()
    }

    fun setVoiceResponsesEnabled(enabled: Boolean) {
        _voiceResponsesEnabled.value = enabled
        prefs.edit().putBoolean("voice_enabled", enabled).apply()
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.destroy()
    }
}
