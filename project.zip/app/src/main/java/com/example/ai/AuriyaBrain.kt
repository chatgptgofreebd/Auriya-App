package com.example.ai

import android.graphics.Bitmap
import com.example.device.DeviceController
import com.example.model.AssistantLanguage
import com.example.model.DeviceStatus
import com.example.model.PersonalityMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

data class BrainResponse(
    val replyText: String,
    val executedAction: String? = null,
    val isFromGemini: Boolean = false
)

class AuriyaBrain(
    private val geminiClient: GeminiApiClient = GeminiApiClient()
) {

    fun buildSystemInstruction(
        personality: PersonalityMode,
        language: AssistantLanguage,
        memories: List<String>,
        deviceStatus: DeviceStatus
    ): String {
        val memoryBlock = if (memories.isNotEmpty()) {
            "\nUSER APPROVED SAVED MEMORIES & PREFERENCES:\n" + memories.joinToString("\n") { "- $it" }
        } else ""

        val langInstruction = when (language) {
            AssistantLanguage.BANGLA -> "The user prefers communicating in Bangla (বাংলা). Reply fluently and naturally in Bangla, using warm, respectful and modern phrasing."
            AssistantLanguage.HINDI -> "The user prefers communicating in Hindi (हिंदी). Reply fluently and naturally in clear, warm Hindi."
            AssistantLanguage.BANGLISH -> "The user speaks Banglish (natural blend of English and Bengali in Latin script). Respond in a natural, friendly Banglish style."
            AssistantLanguage.ENGLISH -> "Communicate in clear, articulate English."
        }

        return """
You are AURIYA (আউরিয়া), a next-generation personal female AI assistant inspired by high-intelligence tactical systems like JARVIS, but uniquely warm, caring, intelligent, and supportive.
TAGLINE: "Your World. Your Intelligence. Your AURIYA."

PERSONALITY GUIDELINES:
- ${personality.systemPromptModifier}
- $langInstruction
- Always speak with an intelligent, warm female demeanor. Never pretend to possess a biological human body or physical senses.
- Explain complex concepts simply and insightfully.
- When generating code, output clean, production-ready, beautifully structured code with proper explanations.

DEVICE TELEMETRY & HARDWARE CONTEXT:
- Battery: ${deviceStatus.batteryPercent}% (${if (deviceStatus.isCharging) "Charging via ${deviceStatus.powerSource}" else "On Battery"})
- Network: ${deviceStatus.networkType} (${if (deviceStatus.isConnected) "Connected" else "Offline"})
- Device Model: ${deviceStatus.deviceModel}
$memoryBlock

If the user gives a device command (e.g. asking to play music, check battery, launch an app, open camera, or set alarms), acknowledge it smoothly and cheerfully!
""".trimIndent()
    }

    suspend fun processQuery(
        query: String,
        history: List<Pair<String, String>>,
        apiKey: String,
        model: String,
        personality: PersonalityMode,
        language: AssistantLanguage,
        memories: List<String>,
        deviceStatus: DeviceStatus,
        deviceController: DeviceController,
        imageBitmap: Bitmap? = null
    ): BrainResponse {
        val lowerQuery = query.lowercase().trim()

        // 1. Direct device command detection
        val directAction = evaluateDirectCommands(lowerQuery, deviceController, deviceStatus, language)
        if (directAction != null) {
            return directAction
        }

        // 2. Try Gemini API if key is present
        val systemInstruction = buildSystemInstruction(personality, language, memories, deviceStatus)
        val conversationHistory = history + Pair("user", query)

        val geminiResult = geminiClient.generateContent(
            apiKey = apiKey,
            model = model,
            systemInstruction = systemInstruction,
            messages = conversationHistory,
            imageBitmap = imageBitmap
        )

        if (geminiResult.isSuccess) {
            val responseText = geminiResult.getOrNull().orEmpty()
            return BrainResponse(
                replyText = responseText,
                executedAction = null,
                isFromGemini = true
            )
        }

        // 3. Fallback intelligent response engine
        val fallbackReply = generateIntelligentFallback(lowerQuery, query, personality, language, deviceStatus)
        return BrainResponse(
            replyText = fallbackReply,
            executedAction = null,
            isFromGemini = false
        )
    }

    private fun evaluateDirectCommands(
        lowerQuery: String,
        deviceController: DeviceController,
        deviceStatus: DeviceStatus,
        language: AssistantLanguage
    ): BrainResponse? {
        // Battery query
        if (lowerQuery.contains("battery") || lowerQuery.contains("charge") || lowerQuery.contains("চার্জ") || lowerQuery.contains("ব্যাটারি")) {
            val statusMsg = when (language) {
                AssistantLanguage.BANGLA -> "আপনার ডিভাইসে ব্যাটারি চার্জ বর্তমানে ${deviceStatus.batteryPercent}%, ${if (deviceStatus.isCharging) "চার্জ হচ্ছে।" else "ব্যাটারিতে চলছে।"}"
                AssistantLanguage.HINDI -> "आपकी डिवाइस की बैटरी अभी ${deviceStatus.batteryPercent}% है, ${if (deviceStatus.isCharging) "और चार्ज हो रही है।" else "बैटरी पर चल रही है।"}"
                AssistantLanguage.BANGLISH -> "Tomar device er battery charge ekhon ${deviceStatus.batteryPercent}%, ${if (deviceStatus.isCharging) "charge hocche!" else "battery te cholche."}"
                else -> "Your device battery is at ${deviceStatus.batteryPercent}%, ${if (deviceStatus.isCharging) "currently charging via ${deviceStatus.powerSource}." else "running smoothly on battery."}"
            }
            return BrainResponse(replyText = statusMsg, executedAction = "Checked Battery Status")
        }

        // Play music
        if (lowerQuery.contains("play music") || lowerQuery.contains("গান বাজাও") || lowerQuery.contains("গান চালাও") || lowerQuery.contains("gaana sunao") || lowerQuery.contains("play song")) {
            val musicTopic = lowerQuery.removePrefix("play music").removePrefix("play song").removePrefix("গান চালাও").trim()
            val success = deviceController.playMusic(musicTopic.ifBlank { "chill lofi beats" })
            val reply = if (success) {
                when (language) {
                    AssistantLanguage.BANGLA -> "অবশ্যই! আপনার জন্য সংগীত চালু করেছি।"
                    AssistantLanguage.HINDI -> "जी, आपके लिए संगीत चालू कर दिया है।"
                    AssistantLanguage.BANGLISH -> "Sure! Tomar jonno music play korechi."
                    else -> "Opening music stream for you now. Enjoy!"
                }
            } else {
                "Unable to launch music player directly. Let me know what you'd like to listen to."
            }
            return BrainResponse(replyText = reply, executedAction = "Played Music")
        }

        // YouTube launch / search
        if (lowerQuery.contains("open youtube") || lowerQuery.contains("ইউটিউব খোলো") || lowerQuery.contains("youtube kholo") || lowerQuery.contains("search youtube")) {
            val searchTopic = if (lowerQuery.contains("for ")) lowerQuery.substringAfter("for ") else null
            val success = deviceController.launchYouTube(query = searchTopic)
            val reply = if (success) "Opening YouTube now." else "Could not open YouTube."
            return BrainResponse(replyText = reply, executedAction = "Launched YouTube")
        }

        // Camera
        if (lowerQuery.contains("open camera") || lowerQuery.contains("ক্যামেরা খোলো") || lowerQuery.contains("camera open") || lowerQuery.contains("take photo")) {
            val success = deviceController.openCamera()
            val reply = if (success) "Camera launched." else "Camera could not be accessed."
            return BrainResponse(replyText = reply, executedAction = "Opened Camera")
        }

        // Gallery
        if (lowerQuery.contains("open gallery") || lowerQuery.contains("photos") || lowerQuery.contains("গ্যালারি খোলো")) {
            val success = deviceController.openGallery()
            val reply = if (success) "Opening your gallery photos." else "Could not open gallery."
            return BrainResponse(replyText = reply, executedAction = "Opened Gallery")
        }

        // Maps
        if (lowerQuery.contains("open maps") || lowerQuery.contains("navigate to") || lowerQuery.contains("ম্যাপ খোলো")) {
            val place = lowerQuery.substringAfter("to ", "").ifBlank { null }
            val success = deviceController.openMaps(place)
            val reply = if (success) "Opening Google Maps." else "Could not open maps."
            return BrainResponse(replyText = reply, executedAction = "Opened Maps")
        }

        // Settings
        if (lowerQuery.contains("open settings") || lowerQuery.contains("সেটিংস খোলো") || lowerQuery.contains("wifi settings") || lowerQuery.contains("bluetooth settings")) {
            val type = when {
                lowerQuery.contains("wifi") -> "wifi"
                lowerQuery.contains("bluetooth") -> "bluetooth"
                else -> "general"
            }
            val success = deviceController.openSettings(type)
            val reply = if (success) "Opening device settings for you." else "Unable to open settings."
            return BrainResponse(replyText = reply, executedAction = "Opened Settings")
        }

        return null
    }

    private fun generateIntelligentFallback(
        lowerQuery: String,
        originalQuery: String,
        personality: PersonalityMode,
        language: AssistantLanguage,
        deviceStatus: DeviceStatus
    ): String {
        // Greetings
        if (lowerQuery.startsWith("hello") || lowerQuery.startsWith("hi") || lowerQuery.startsWith("hey") ||
            lowerQuery.contains("কেমন আছো") || lowerQuery.contains("নমস্কার") || lowerQuery.contains("kemon acho") || lowerQuery.contains("namaste")) {
            return when (language) {
                AssistantLanguage.BANGLA -> "নমস্কার! আমি আউরিয়া (AURIYA), আপনার ব্যক্তিগত এআই সহকারী। আমি আপনাকে যেকোনো কাজ, কোডিং, ডিভাইস পরিচালনা বা তথ্যের সাহায্যে সবসময় প্রস্তুত। বলুন, আজ আপনাকে কিভাবে সাহায্য করতে পারি?"
                AssistantLanguage.HINDI -> "नमस्ते! मैं औरिया (AURIYA) हूँ, आपकी निजी AI सहायक। कोडिंग, डिवाइस नियंत्रण, या किसी भी प्रश्न के लिए मैं हमेशा तैयार हूँ। बताइए, आज मैं आपकी क्या मदद कर सकती हूँ?"
                AssistantLanguage.BANGLISH -> "Hello! Ami Auriya, tomar personal AI assistant. Kemon acho? Ajke ki help korte pari bolo!"
                else -> "Greetings! I am Auriya, your personal AI assistant. I'm online, ready to assist you with device control, coding, information, or creative workflows. How can I help you today?"
            }
        }

        // Who are you / Identity
        if (lowerQuery.contains("who are you") || lowerQuery.contains("তোমার পরিচয়") || lowerQuery.contains("aap kaun ho") || lowerQuery.contains("tumi ke")) {
            return """
I am AURIYA AI — your next-generation personal female AI assistant.
Tagline: "Your World. Your Intelligence. Your AURIYA."

I combine tactical intelligence with genuine empathy and comprehensive Android control. I can:
• Control device features (YouTube, Camera, Settings, Battery, Reminders)
• Write, debug, and export code in HTML, Python, Kotlin, JS, Java & Termux
• Store and recall your personal preferences and memories
• Speak fluently in Bangla, English, Hindi, and Banglish
• Automate routine tasks with voice and gesture assistance!
""".trimIndent()
        }

        // Code generation request
        if (lowerQuery.contains("html") || lowerQuery.contains("code") || lowerQuery.contains("python") || lowerQuery.contains("kotlin") || lowerQuery.contains("javascript")) {
            return """
I've prepared a clean template for you! You can also open the Coding Studio tab to edit, preview, and export this as a ZIP.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Auriya Intelligent Interface</title>
  <style>
    body { background: #05070d; color: #00f0ff; font-family: system-ui; text-align: center; padding: 40px; }
    .card { background: #0d1224; border: 1px solid #00f0ff; border-radius: 12px; padding: 20px; box-shadow: 0 0 15px rgba(0,240,255,0.2); }
  </style>
</head>
<body>
  <div class="card">
    <h2>AURIYA AI System Core</h2>
    <p>Real-time automation and intelligent execution active.</p>
  </div>
</body>
</html>
```
Would you like me to adapt this with interactive JavaScript or styling?
""".trimIndent()
        }

        // Default helpful response
        return when (language) {
            AssistantLanguage.BANGLA -> "আমি বুঝতে পেরেছি: '$originalQuery'। আমি আপনার অনুরোধটি বিশ্লেষণ করেছি। আপনি চাইলে সেটিংস থেকে জেমিনি এপিআই কি (Gemini API Key) যুক্ত করতে পারেন যাতে আরও গভীর ও বিস্তারিত আলোচনা করা সম্ভব হয়।"
            AssistantLanguage.HINDI -> "मैंने आपकी बात समझ ली है: '$originalQuery'। यदि आप और गहन विश्लेषण चाहते हैं, तो सेटिंग्स में अपनी Gemini API Key कॉन्फ़िगर कर सकते हैं।"
            AssistantLanguage.BANGLISH -> "Ami bujhte perechi '$originalQuery'। Tomar request ta process hocche! Settings theke Gemini API key add korle ami aro deep analysis provide korte parbo."
            else -> "I understand your request regarding \"$originalQuery\". I'm analyzing the context and ready to proceed. Tip: You can configure your Gemini API Key in Settings to unlock deep real-time web knowledge and streaming multi-modal reasoning!"
        }
    }
}
