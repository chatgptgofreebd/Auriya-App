package com.example.ai

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

data class GeminiGenerationConfig(
    val temperature: Float = 0.7f,
    val topP: Float = 0.95f,
    val topK: Int = 40,
    val maxOutputTokens: Int = 2048
)

class GeminiApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    companion object {
        const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
        val AVAILABLE_MODELS = listOf(
            "gemini-2.5-flash" to "Gemini 2.5 Flash (Fast & Intelligent)",
            "gemini-2.5-pro" to "Gemini 2.5 Pro (Deep Reasoning)",
            "gemini-1.5-flash" to "Gemini 1.5 Flash (Efficient)",
            "gemini-1.5-pro" to "Gemini 1.5 Pro (Balanced)"
        )
    }

    suspend fun generateContent(
        apiKey: String,
        model: String = "gemini-2.5-flash",
        systemInstruction: String,
        messages: List<Pair<String, String>>, // role ("user" | "model") -> text
        imageBitmap: Bitmap? = null,
        config: GeminiGenerationConfig = GeminiGenerationConfig()
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(IllegalStateException("API key is not configured"))
        }

        try {
            val url = "$BASE_URL/$model:generateContent?key=$apiKey"
            val jsonPayload = buildPayload(systemInstruction, messages, imageBitmap, config)

            val requestBody = jsonPayload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody == null) {
                val errorMsg = try {
                    JSONObject(responseBody ?: "").optJSONObject("error")?.optString("message")
                        ?: "HTTP ${response.code}: ${response.message}"
                } catch (_: Exception) {
                    "HTTP ${response.code}: ${response.message}"
                }
                return@withContext Result.failure(Exception(errorMsg))
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val text = parts.getJSONObject(0).optString("text", "")
                    return@withContext Result.success(text)
                }
            }

            Result.failure(Exception("No content returned from Gemini API"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun streamGenerateContent(
        apiKey: String,
        model: String = "gemini-2.5-flash",
        systemInstruction: String,
        messages: List<Pair<String, String>>,
        config: GeminiGenerationConfig = GeminiGenerationConfig()
    ): Flow<String> = flow {
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalStateException("API key is not configured")
        }

        val url = "$BASE_URL/$model:streamGenerateContent?alt=sse&key=$apiKey"
        val jsonPayload = buildPayload(systemInstruction, messages, null, config)

        val requestBody = jsonPayload.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val errBody = response.body?.string()
            throw Exception("HTTP ${response.code}: $errBody")
        }

        val source = response.body?.byteStream() ?: throw Exception("Empty stream")
        val reader = BufferedReader(InputStreamReader(source))
        var line: String?

        while (reader.readLine().also { line = it } != null) {
            val currentLine = line ?: continue
            if (currentLine.startsWith("data: ")) {
                val data = currentLine.removePrefix("data: ").trim()
                if (data.isNotEmpty()) {
                    try {
                        val json = JSONObject(data)
                        val candidates = json.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val candidate = candidates.getJSONObject(0)
                            val content = candidate.optJSONObject("content")
                            val parts = content?.optJSONArray("parts")
                            if (parts != null && parts.length() > 0) {
                                val textPart = parts.getJSONObject(0).optString("text", "")
                                if (textPart.isNotEmpty()) {
                                    emit(textPart)
                                }
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun buildPayload(
        systemInstruction: String,
        messages: List<Pair<String, String>>,
        imageBitmap: Bitmap?,
        config: GeminiGenerationConfig
    ): JSONObject {
        val root = JSONObject()

        // System Instruction
        if (systemInstruction.isNotBlank()) {
            val sysObj = JSONObject()
            val sysParts = JSONArray()
            val sysTextPart = JSONObject().put("text", systemInstruction)
            sysParts.put(sysTextPart)
            sysObj.put("parts", sysParts)
            root.put("systemInstruction", sysObj)
        }

        // Contents
        val contentsArray = JSONArray()
        for (i in messages.indices) {
            val (role, text) = messages[i]
            val contentObj = JSONObject()
            contentObj.put("role", if (role.equals("model", ignoreCase = true) || role.equals("auriya", ignoreCase = true)) "model" else "user")
            val partsArray = JSONArray()

            // If last user message and imageBitmap exists, add inline data
            if (i == messages.lastIndex && role.equals("user", ignoreCase = true) && imageBitmap != null) {
                val imagePart = JSONObject()
                val inlineData = JSONObject()
                inlineData.put("mimeType", "image/jpeg")
                inlineData.put("data", bitmapToBase64(imageBitmap))
                imagePart.put("inlineData", inlineData)
                partsArray.put(imagePart)
            }

            val textPart = JSONObject().put("text", text)
            partsArray.put(textPart)
            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
        }
        root.put("contents", contentsArray)

        // Generation Config
        val genConfig = JSONObject()
        genConfig.put("temperature", config.temperature)
        genConfig.put("topP", config.topP)
        genConfig.put("topK", config.topK)
        genConfig.put("maxOutputTokens", config.maxOutputTokens)
        root.put("generationConfig", genConfig)

        return root
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
}
