package com.example.model

enum class MessageRole {
    USER,
    AURIYA,
    SYSTEM
}

data class ChatMessage(
    val id: Long = System.currentTimeMillis(),
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionTag: String? = null,
    val imageUri: String? = null,
    val isStreaming: Boolean = false
)
