package com.example.model

import java.util.Locale

object LanguageDetector {

    /**
     * Detects whether the input text is primarily Bangla, Hindi, or English.
     */
    fun detectLanguage(text: String): AssistantLanguage {
        if (text.isBlank()) return AssistantLanguage.ENGLISH

        var bengaliCount = 0
        var devanagariCount = 0
        var latinCount = 0

        for (char in text) {
            val codePoint = char.code
            when {
                codePoint in 0x0980..0x09FF -> bengaliCount++
                codePoint in 0x0900..0x097F -> devanagariCount++
                (codePoint in 'a'.code..'z'.code) || (codePoint in 'A'.code..'Z'.code) -> latinCount++
            }
        }

        return when {
            bengaliCount > 0 && bengaliCount >= devanagariCount -> AssistantLanguage.BANGLA
            devanagariCount > 0 && devanagariCount > bengaliCount -> AssistantLanguage.HINDI
            else -> AssistantLanguage.ENGLISH
        }
    }

    /**
     * Returns the appropriate TTS Locale for the detected language.
     */
    fun getTtsLocale(language: AssistantLanguage): Locale {
        return when (language) {
            AssistantLanguage.BANGLA -> Locale("bn", "BD")
            AssistantLanguage.HINDI -> Locale("hi", "IN")
            AssistantLanguage.BANGLISH -> Locale.US
            AssistantLanguage.ENGLISH -> Locale.US
        }
    }
}
