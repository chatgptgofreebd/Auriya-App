package com.example.model

enum class ActionType(val label: String, val description: String) {
    LAUNCH_YOUTUBE("Launch YouTube", "Open YouTube app or search"),
    PLAY_MUSIC("Play Music", "Play music on YouTube or default player"),
    OPEN_CAMERA("Open Camera", "Open device camera"),
    OPEN_GALLERY("Open Gallery", "Open device photos/gallery"),
    BATTERY_STATUS("Battery Status", "Query battery state & report with voice"),
    NETWORK_STATUS("Network Status", "Check WiFi/Cellular connectivity"),
    OPEN_SETTINGS("Open Settings", "Launch Android system settings"),
    OPEN_MAPS("Open Maps", "Open navigation or search location"),
    SET_ALARM("Set Alarm", "Create system alarm"),
    OPEN_CODING_STUDIO("Open Code Studio", "Launch internal coding workspace"),
    CUSTOM_AI_PROMPT("Custom AI Task", "Execute pre-configured AI command")
}

data class AutomationRule(
    val id: Long = 0,
    val title: String,
    val triggerPhrase: String,
    val actionType: ActionType,
    val actionParam: String = "",
    val isEnabled: Boolean = true
)
