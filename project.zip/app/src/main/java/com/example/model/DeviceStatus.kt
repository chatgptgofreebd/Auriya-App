package com.example.model

data class DeviceStatus(
    val batteryPercent: Int = 100,
    val isCharging: Boolean = false,
    val powerSource: String = "Battery",
    val networkType: String = "WiFi",
    val isConnected: Boolean = true,
    val freeStorageGb: Double = 32.5,
    val availableRamGb: Double = 4.2,
    val deviceModel: String = "Android Device"
)
