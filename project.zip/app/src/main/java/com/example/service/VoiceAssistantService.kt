package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.R
import com.example.ai.AuriyaBrain
import com.example.data.local.AppDatabase
import com.example.data.local.ConversationEntity
import com.example.device.DeviceController
import com.example.model.AssistantLanguage
import com.example.model.LanguageDetector
import com.example.model.MessageRole
import com.example.model.PersonalityMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

enum class VoiceStatus {
    IDLE,
    WAKE_WORD_WAITING,
    ACTIVE_LISTENING,
    THINKING,
    SPEAKING
}

data class VoiceAssistantState(
    val isRunning: Boolean = false,
    val status: VoiceStatus = VoiceStatus.IDLE,
    val statusDescription: String = "Background Assistant Inactive",
    val userSpokenText: String = "",
    val aiResponseText: String = "",
    val detectedLanguage: AssistantLanguage = AssistantLanguage.ENGLISH,
    val rmsLevel: Float = 0f
)

class VoiceAssistantService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "auriya_voice_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_SERVICE = "com.example.action.START_SERVICE"
        const val ACTION_STOP_SERVICE = "com.example.action.STOP_SERVICE"
        const val ACTION_TRIGGER_MIC = "com.example.action.TRIGGER_MIC"
        const val ACTION_STOP_TTS = "com.example.action.STOP_TTS"

        private val _serviceState = MutableStateFlow(VoiceAssistantState())
        val serviceState: StateFlow<VoiceAssistantState> = _serviceState.asStateFlow()

        val WAKE_WORDS_ENGLISH = listOf("hey auriya", "auriya", "hi auriya", "ok auriya", "hello auriya")
        val WAKE_WORDS_BANGLA = listOf("হেই অউরিয়া", "অউরিয়া", "ওরিয়া", "হেই অরিয়া", "হেই আউরিয়া", "আউরিয়া", "হে অউরিয়া", "হেই ওরিয়া")
        val WAKE_WORDS_HINDI = listOf("हे ओरिया", "ओरिया", "हे औरिया", "औरिये", "नमस्ते औरिया", "हे आउरिया", "सुनो औरिया")

        fun startService(context: Context) {
            val intent = Intent(context, VoiceAssistantService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, VoiceAssistantService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }

        fun triggerMic(context: Context) {
            val intent = Intent(context, VoiceAssistantService::class.java).apply {
                action = ACTION_TRIGGER_MIC
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false
    private var wakeLock: PowerManager.WakeLock? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var database: AppDatabase
    private lateinit var deviceController: DeviceController
    private val brain = AuriyaBrain()

    private var isContinuousListeningMode = false
    private var isListeningSessionActive = false

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(applicationContext)
        deviceController = DeviceController(applicationContext)

        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Auriya::VoiceWakeLock")

        createNotificationChannel()
        initializeTts()
        initializeSpeechRecognizer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                stopAssistant()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TRIGGER_MIC -> {
                // Immediate manual mic trigger or interrupt
                interruptSpeakingAndStartListening()
            }
            ACTION_STOP_TTS -> {
                stopSpeaking()
            }
            else -> {
                startAssistant()
            }
        }
        return START_STICKY
    }

    private fun startAssistant() {
        wakeLock?.acquire(10 * 60 * 1000L /* 10 minutes max */)

        val notification = buildNotification("Listening for 'Hey Auriya'...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        _serviceState.value = _serviceState.value.copy(
            isRunning = true,
            status = VoiceStatus.WAKE_WORD_WAITING,
            statusDescription = "Listening for 'Hey Auriya'..."
        )

        startWakeWordListeningLoop()
    }

    private fun stopAssistant() {
        isContinuousListeningMode = false
        stopListening()
        stopSpeaking()

        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }

        _serviceState.value = VoiceAssistantState(
            isRunning = false,
            status = VoiceStatus.IDLE,
            statusDescription = "Background Assistant Inactive"
        )
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun initializeTts() {
        textToSpeech = TextToSpeech(applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            textToSpeech?.setPitch(1.15f) // Feminine pleasant pitch
            textToSpeech?.setSpeechRate(1.0f)
            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _serviceState.value = _serviceState.value.copy(
                        status = VoiceStatus.SPEAKING,
                        statusDescription = "Auriya is speaking..."
                    )
                    updateNotification("Auriya is speaking...")
                }

                override fun onDone(utteranceId: String?) {
                    // HANDS-FREE CONTINUOUS CONVERSATION:
                    // After AI finishes speaking, automatically start listening again!
                    mainHandler.post {
                        if (_serviceState.value.isRunning) {
                            startActiveListening(promptText = "Listening for your reply...")
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    mainHandler.post {
                        if (_serviceState.value.isRunning) {
                            startWakeWordListeningLoop()
                        }
                    }
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    mainHandler.post {
                        if (_serviceState.value.isRunning) {
                            startWakeWordListeningLoop()
                        }
                    }
                }
            })
        }
    }

    private fun initializeSpeechRecognizer() {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(this@VoiceAssistantService)
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Minimal battery wake-word listening loop
     */
    private fun startWakeWordListeningLoop() {
        if (!_serviceState.value.isRunning) return
        isContinuousListeningMode = false

        stopSpeaking()
        stopListening()

        _serviceState.value = _serviceState.value.copy(
            status = VoiceStatus.WAKE_WORD_WAITING,
            statusDescription = "Listening for 'Hey Auriya' (Bangla/English/Hindi)..."
        )
        updateNotification("Listening for 'Hey Auriya'...")

        mainHandler.postDelayed({
            if (_serviceState.value.status == VoiceStatus.WAKE_WORD_WAITING && _serviceState.value.isRunning) {
                launchRecognizer(isWakeWordOnly = true)
            }
        }, 300)
    }

    /**
     * Active speech recognition for hands-free query
     */
    fun startActiveListening(promptText: String = "Listening to your voice...") {
        if (!_serviceState.value.isRunning) return
        isContinuousListeningMode = true

        stopSpeaking()
        stopListening()

        _serviceState.value = _serviceState.value.copy(
            status = VoiceStatus.ACTIVE_LISTENING,
            statusDescription = promptText
        )
        updateNotification(promptText)

        mainHandler.postDelayed({
            if (_serviceState.value.isRunning) {
                launchRecognizer(isWakeWordOnly = false)
            }
        }, 200)
    }

    /**
     * INTERRUPTION HANDLING:
     * If user starts speaking while TTS is active, stop TTS immediately & start listening.
     */
    fun interruptSpeakingAndStartListening() {
        stopSpeaking()
        deviceController.triggerHaptic()
        startActiveListening("Listening to you...")
    }

    private fun launchRecognizer(isWakeWordOnly: Boolean) {
        if (speechRecognizer == null) {
            initializeSpeechRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // Support multi-language recognition
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("bn-BD", "hi-IN", "en-US"))
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            if (isWakeWordOnly) {
                // Short listening window for wake word
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            } else {
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            }
        }

        try {
            speechRecognizer?.startListening(intent)
            isListeningSessionActive = true
        } catch (_: Exception) {
            isListeningSessionActive = false
            scheduleRecognizerRestart(isWakeWordOnly)
        }
    }

    private fun scheduleRecognizerRestart(isWakeWordOnly: Boolean) {
        mainHandler.postDelayed({
            if (_serviceState.value.isRunning) {
                if (isWakeWordOnly) {
                    startWakeWordListeningLoop()
                } else {
                    startActiveListening()
                }
            }
        }, 600)
    }

    private fun stopListening() {
        try {
            isListeningSessionActive = false
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (_: Exception) {}
        _serviceState.value = _serviceState.value.copy(rmsLevel = 0f)
    }

    private fun stopSpeaking() {
        try {
            textToSpeech?.stop()
        } catch (_: Exception) {}
        if (_serviceState.value.status == VoiceStatus.SPEAKING) {
            _serviceState.value = _serviceState.value.copy(status = VoiceStatus.IDLE)
        }
    }

    // Speech Recognition Callbacks
    override fun onReadyForSpeech(params: Bundle?) {}

    override fun onBeginningOfSpeech() {
        // If speaking, user interrupted by beginning to speak!
        if (_serviceState.value.status == VoiceStatus.SPEAKING) {
            stopSpeaking()
            _serviceState.value = _serviceState.value.copy(
                status = VoiceStatus.ACTIVE_LISTENING,
                statusDescription = "Interruption detected. Listening..."
            )
        }
    }

    override fun onRmsChanged(rmsdB: Float) {
        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.1f, 1f)
        _serviceState.value = _serviceState.value.copy(rmsLevel = normalized)

        // Audio spike interruption while TTS is speaking
        if (_serviceState.value.status == VoiceStatus.SPEAKING && normalized > 0.75f) {
            interruptSpeakingAndStartListening()
        }
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        _serviceState.value = _serviceState.value.copy(rmsLevel = 0f)
    }

    override fun onError(error: Int) {
        _serviceState.value = _serviceState.value.copy(rmsLevel = 0f)
        isListeningSessionActive = false

        if (!_serviceState.value.isRunning) return

        when (_serviceState.value.status) {
            VoiceStatus.WAKE_WORD_WAITING -> {
                // Brief 400ms pause to conserve battery before re-listening for wake word
                mainHandler.postDelayed({
                    if (_serviceState.value.isRunning && _serviceState.value.status == VoiceStatus.WAKE_WORD_WAITING) {
                        launchRecognizer(isWakeWordOnly = true)
                    }
                }, 400)
            }
            VoiceStatus.ACTIVE_LISTENING -> {
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    // Timeout in active conversation: return to low-power wake word waiting
                    startWakeWordListeningLoop()
                } else {
                    scheduleRecognizerRestart(isWakeWordOnly = false)
                }
            }
            else -> {}
        }
    }

    override fun onResults(results: Bundle?) {
        _serviceState.value = _serviceState.value.copy(rmsLevel = 0f)
        isListeningSessionActive = false

        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (matches.isNullOrEmpty()) {
            if (_serviceState.value.status == VoiceStatus.ACTIVE_LISTENING) {
                startWakeWordListeningLoop()
            } else {
                startWakeWordListeningLoop()
            }
            return
        }

        val spokenText = matches[0].trim()
        if (spokenText.isBlank()) {
            startWakeWordListeningLoop()
            return
        }

        if (_serviceState.value.status == VoiceStatus.WAKE_WORD_WAITING) {
            handleWakeWordMatch(spokenText)
        } else {
            processUserQuery(spokenText)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val partial = matches[0].trim().lowercase()

            // If we are waiting for wake word, check if partial text matches wake word
            if (_serviceState.value.status == VoiceStatus.WAKE_WORD_WAITING) {
                if (containsWakeWord(partial)) {
                    stopListening()
                    deviceController.triggerHaptic()
                    val strippedQuery = stripWakeWord(matches[0])
                    if (strippedQuery.isNotBlank()) {
                        processUserQuery(strippedQuery)
                    } else {
                        startActiveListening("Wake word detected! Listening...")
                    }
                }
            }
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    private fun handleWakeWordMatch(spokenText: String) {
        val lower = spokenText.lowercase()
        if (containsWakeWord(lower)) {
            deviceController.triggerHaptic()
            val queryAfterWakeWord = stripWakeWord(spokenText)
            if (queryAfterWakeWord.isNotBlank()) {
                processUserQuery(queryAfterWakeWord)
            } else {
                startActiveListening("I'm listening! Speak now...")
            }
        } else {
            // No wake word match, keep waiting
            startWakeWordListeningLoop()
        }
    }

    private fun containsWakeWord(text: String): Boolean {
        val cleaned = text.lowercase()
            .replace(",", "")
            .replace(".", "")
            .replace("!", "")
            .replace("?", "")

        return WAKE_WORDS_ENGLISH.any { cleaned.contains(it) } ||
                WAKE_WORDS_BANGLA.any { cleaned.contains(it) } ||
                WAKE_WORDS_HINDI.any { cleaned.contains(it) }
    }

    private fun stripWakeWord(text: String): String {
        var result = text
        (WAKE_WORDS_ENGLISH + WAKE_WORDS_BANGLA + WAKE_WORDS_HINDI).forEach { word ->
            result = result.replace(Regex("(?i)\\b$word\\b"), "")
                .replace(word, "")
        }
        return result.trim().removePrefix(",").removePrefix(".").trim()
    }

    /**
     * Processes user speech:
     * 1. Updates state to THINKING
     * 2. Detects user language
     * 3. Sends query to AuriyaBrain (with language matching rule)
     * 4. Saves message in Room Database
     * 5. Speakes response with dynamic language detection in TTS
     */
    private fun processUserQuery(query: String) {
        val detectedUserLang = LanguageDetector.detectLanguage(query)

        _serviceState.value = _serviceState.value.copy(
            status = VoiceStatus.THINKING,
            statusDescription = "Auriya is thinking...",
            userSpokenText = query,
            detectedLanguage = detectedUserLang
        )
        updateNotification("Thinking: \"${query.take(30)}...\"")

        serviceScope.launch(Dispatchers.IO) {
            // Save user query to Room DB
            database.conversationDao().insertMessage(
                ConversationEntity(
                    role = MessageRole.USER.name,
                    content = query,
                    timestamp = System.currentTimeMillis()
                )
            )

            // Read preferences
            val prefs = getSharedPreferences("auriya_prefs", Context.MODE_PRIVATE)
            val apiKey = prefs.getString("custom_api_key", "")?.trim().orEmpty()
            val model = prefs.getString("selected_model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
            val personalityName = prefs.getString("personality", PersonalityMode.EMPATHETIC_ASSISTANT.name)
            val personality = try { PersonalityMode.valueOf(personalityName!!) } catch (_: Exception) { PersonalityMode.EMPATHETIC_ASSISTANT }

            val memories = database.memoryDao().getMemoriesSnapshot().map { "${it.key}: ${it.value}" }
            val deviceStatus = deviceController.getDeviceStatus()

            val history = database.conversationDao().getAllMessages()
            // Take recent history
            val snapshotHistory = database.memoryDao().getMemoriesSnapshot() // dummy to warm up

            val response = brain.processQuery(
                query = query,
                history = emptyList(),
                apiKey = apiKey,
                model = model,
                personality = personality,
                language = detectedUserLang,
                memories = memories,
                deviceStatus = deviceStatus,
                deviceController = deviceController
            )

            // Save AI reply to Room DB
            database.conversationDao().insertMessage(
                ConversationEntity(
                    role = MessageRole.AURIYA.name,
                    content = response.replyText,
                    timestamp = System.currentTimeMillis(),
                    actionTag = response.executedAction
                )
            )

            serviceScope.launch(Dispatchers.Main) {
                _serviceState.value = _serviceState.value.copy(
                    aiResponseText = response.replyText,
                    status = VoiceStatus.SPEAKING,
                    statusDescription = "Auriya is speaking..."
                )
                speakResponseWithDynamicLanguage(response.replyText)
            }
        }
    }

    /**
     * DYNAMIC LANGUAGE DETECTION & TTS:
     * Detects response language and configures TTS Locale before speaking.
     * Fallback to English if language data is missing or unsupported.
     */
    private fun speakResponseWithDynamicLanguage(text: String) {
        if (!isTtsInitialized || text.isBlank()) {
            startWakeWordListeningLoop()
            return
        }

        val cleaned = cleanTextForSpeech(text)
        if (cleaned.isBlank()) {
            startWakeWordListeningLoop()
            return
        }

        val detectedLang = LanguageDetector.detectLanguage(cleaned)
        val targetLocale = LanguageDetector.getTtsLocale(detectedLang)

        // Configure TTS Locale dynamically
        val langResult = textToSpeech?.setLanguage(targetLocale)
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to English
            textToSpeech?.language = Locale.US
        }

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "auriya_bg_${System.currentTimeMillis()}")
        }

        textToSpeech?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, params, "auriya_bg_${System.currentTimeMillis()}")
    }

    private fun cleanTextForSpeech(raw: String): String {
        return raw.replace(Regex("```[\\s\\S]*?```"), "Code generated.")
            .replace(Regex("`[^`]*`"), "")
            .replace(Regex("[*#_~]"), "")
            .trim()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AURIYA AI Background Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Continuous background voice listening and wake word activation for AURIYA AI"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusMessage: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, VoiceAssistantService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AURIYA AI Voice Assistant")
            .setContentText(statusMessage)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(statusMessage: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, buildNotification(statusMessage))
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        try {
            speechRecognizer?.destroy()
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {}
        _serviceState.value = VoiceAssistantState(isRunning = false, status = VoiceStatus.IDLE)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
