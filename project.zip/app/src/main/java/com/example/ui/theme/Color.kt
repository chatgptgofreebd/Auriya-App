package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBlack = Color(0xFF05070D)
val CyberDark = Color(0xFF090D1A)
val CyberSurface = Color(0xFF10172A)
val CyberSurfaceVariant = Color(0xFF162038)
val CyberBorder = Color(0x3300F0FF)
val CyberBorderPurple = Color(0x338A2BE2)

val CyberCyan = Color(0xFF00F0FF)
val CyberCyanGlow = Color(0x6600F0FF)
val ElectricBlue = Color(0xFF0084FF)
val NeonPurple = Color(0xFF9D4EDD)
val NeonMagenta = Color(0xFFFF2A85)
val NeonGreen = Color(0xFF00FFA3)
val CyberGold = Color(0xFFFFD166)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val GlassBackground = Color(0xBF0B1120)
val GlassSurface = Color(0x80131C35)
