package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import kotlin.math.sin

@Composable
fun VoiceWaveformVisualizer(
    isActive: Boolean,
    audioLevel: Float = 0f,
    modifier: Modifier = Modifier
) {
    val barCount = 18
    val transition = rememberInfiniteTransition(label = "waveform_anim")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Row(
        modifier = modifier.height(36.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until barCount) {
            val baseSine = (sin((phase + (i * 0.45f)).toDouble()).toFloat() + 1f) / 2f
            val heightFraction = if (isActive) {
                ((baseSine * 0.4f) + (audioLevel * 0.6f)).coerceIn(0.15f, 1f)
            } else {
                0.12f
            }

            Box(
                modifier = Modifier
                    .width(3.5.dp)
                    .height((36 * heightFraction).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = if (isActive) {
                                listOf(CyberCyan, NeonPurple, NeonMagenta)
                            } else {
                                listOf(Color(0xFF202A44), Color(0xFF141A2D))
                            }
                        )
                    )
            )
        }
    }
}
