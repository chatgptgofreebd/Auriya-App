package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AssistantStatus
import com.example.MainViewModel
import com.example.NavigationTab
import com.example.ui.components.AnimatedAuriyaCore
import com.example.ui.components.VoiceWaveformVisualizer
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderPurple
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val assistantStatus by viewModel.assistantStatus.collectAsState()
    val deviceStatus by viewModel.deviceStatus.collectAsState()
    val personality by viewModel.personality.collectAsState()
    val language by viewModel.language.collectAsState()
    val isListening by viewModel.voiceEngine.isListening.collectAsState()
    val isSpeaking by viewModel.voiceEngine.isSpeaking.collectAsState()
    val audioLevel by viewModel.voiceEngine.rmsLevel.collectAsState()

    var quickInputText by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Top Status Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AURIYA AI",
                    style = MaterialTheme.typography.headlineSmall,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Your World. Your Intelligence. Your AURIYA.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            // Live status badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, RoundedCornerShape(16.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                when (assistantStatus) {
                                    AssistantStatus.LISTENING -> CyberCyan
                                    AssistantStatus.SPEAKING -> NeonMagenta
                                    AssistantStatus.THINKING -> NeonPurple
                                    AssistantStatus.IDLE -> NeonGreen
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when (assistantStatus) {
                            AssistantStatus.LISTENING -> "LISTENING"
                            AssistantStatus.SPEAKING -> "SPEAKING"
                            AssistantStatus.THINKING -> "COMPUTING"
                            AssistantStatus.IDLE -> "ONLINE"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Animated Holographic Core
        AnimatedAuriyaCore(
            status = assistantStatus,
            audioLevel = audioLevel,
            size = 230.dp,
            onClick = {
                if (isListening) {
                    viewModel.stopListening()
                } else if (isSpeaking) {
                    viewModel.stopSpeaking()
                } else {
                    viewModel.startListening()
                }
            }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Audio Waveform Visualizer
        VoiceWaveformVisualizer(
            isActive = isListening || isSpeaking,
            audioLevel = audioLevel,
            modifier = Modifier.fillMaxWidth(0.7f)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Subtitle status prompt
        Text(
            text = when {
                isListening -> "Listening in ${language.displayName}... Tap to finish"
                isSpeaking -> "Auriya is responding... Tap core to pause"
                assistantStatus == AssistantStatus.THINKING -> "Analyzing neural context..."
                else -> "Tap the AI Core or speak to start"
            },
            style = MaterialTheme.typography.bodyMedium,
            color = if (isListening) CyberCyan else TextSecondary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Command Action Chips
        Text(
            text = "TACTICAL SHORTCUTS",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(),
            letterSpacing = 1.2.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickActionChip(
                label = "Open YouTube",
                icon = Icons.Default.PlayArrow,
                accentColor = CyberCyan
            ) {
                viewModel.handleUserPrompt("open youtube")
            }

            QuickActionChip(
                label = "Battery Status",
                icon = Icons.Default.BatteryChargingFull,
                accentColor = NeonGreen
            ) {
                viewModel.handleUserPrompt("tell me battery status")
            }

            QuickActionChip(
                label = "Play Chill Music",
                icon = Icons.Default.MusicNote,
                accentColor = NeonMagenta
            ) {
                viewModel.handleUserPrompt("play my music")
            }

            QuickActionChip(
                label = "Code Studio",
                icon = Icons.Default.Code,
                accentColor = ElectricBlue
            ) {
                viewModel.setTab(NavigationTab.CODING)
            }

            QuickActionChip(
                label = "Open Camera",
                icon = Icons.Default.CameraAlt,
                accentColor = CyberCyan
            ) {
                viewModel.handleUserPrompt("open camera")
            }

            QuickActionChip(
                label = "System Settings",
                icon = Icons.Default.Settings,
                accentColor = NeonPurple
            ) {
                viewModel.handleUserPrompt("open settings")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Device Telemetry Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDark),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CyberBorder, CyberBorderPurple)))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DEVICE TELEMETRY",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    IconButton(
                        onClick = { viewModel.refreshDeviceStatus() },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Status",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TelemetryItem(
                        icon = if (deviceStatus.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                        label = "Battery",
                        value = "${deviceStatus.batteryPercent}% (${if (deviceStatus.isCharging) "Charging" else "Battery"})",
                        tint = if (deviceStatus.batteryPercent > 20) NeonGreen else Color(0xFFFF5252)
                    )

                    TelemetryItem(
                        icon = if (deviceStatus.isConnected) Icons.Default.Wifi else Icons.Default.WifiOff,
                        label = "Network",
                        value = deviceStatus.networkType,
                        tint = if (deviceStatus.isConnected) CyberCyan else Color(0xFFFF5252)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TelemetryItem(
                        icon = Icons.Default.Chat,
                        label = "Personality",
                        value = personality.title,
                        tint = NeonPurple
                    )

                    TelemetryItem(
                        icon = Icons.Default.VolumeUp,
                        label = "Voice Language",
                        value = language.displayName,
                        tint = ElectricBlue
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bottom Fast Prompt Input Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(CyberSurface)
                .border(1.dp, CyberBorder, RoundedCornerShape(24.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (isListening) viewModel.stopListening() else viewModel.startListening()
                },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (isListening) CyberCyan else Color(0x3300F0FF))
                    .testTag("home_mic_button")
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Voice Input",
                    tint = if (isListening) CyberBlack else CyberCyan
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            OutlinedTextField(
                value = quickInputText,
                onValueChange = { quickInputText = it },
                placeholder = {
                    Text(
                        text = "Ask AURIYA or command device...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("home_text_input")
            )

            IconButton(
                onClick = {
                    if (quickInputText.isNotBlank()) {
                        val text = quickInputText
                        quickInputText = ""
                        viewModel.handleUserPrompt(text)
                    }
                },
                enabled = quickInputText.isNotBlank(),
                modifier = Modifier.testTag("home_send_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = if (quickInputText.isNotBlank()) CyberCyan else TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun QuickActionChip(
    label: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(CyberSurface)
            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun TelemetryItem(
    icon: ImageVector,
    label: String,
    value: String,
    tint: Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 10.sp
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                color = TextPrimary,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp
            )
        }
    }
}
