package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel
import com.example.ai.GeminiApiClient
import com.example.model.AssistantLanguage
import com.example.model.PersonalityMode
import com.example.service.AuriyaAccessibilityService
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderPurple
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val currentPersonality by viewModel.personality.collectAsState()
    val currentLanguage by viewModel.language.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val customApiKey by viewModel.customApiKey.collectAsState()
    val temperature by viewModel.temperature.collectAsState()
    val voicePitch by viewModel.voicePitch.collectAsState()
    val voiceRate by viewModel.voiceRate.collectAsState()
    val voiceEnabled by viewModel.voiceResponsesEnabled.collectAsState()
    val handsFreeContinuous by viewModel.handsFreeContinuous.collectAsState()
    val voiceServiceState by viewModel.voiceServiceState.collectAsState()
    val isAccessibilityActive by AuriyaAccessibilityService.isServiceActive.collectAsState()

    var apiKeyInput by remember(customApiKey) { mutableStateOf(customApiKey) }
    var showApiKey by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(14.dp))

        // Header
        Text(
            text = "AURIYA CONTROL MATRIX",
            style = MaterialTheme.typography.titleMedium,
            color = CyberCyan,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Text(
            text = "AI Brain, Neural Voice, Device Access, and Security Config",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 1. PREMIUM BACKGROUND VOICE & WAKE-WORD COMBO
        SettingsSectionCard(title = "PREMIUM BACKGROUND VOICE & WAKE-WORD", icon = Icons.Default.Hearing) {
            // Background service toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Continuous Background Listening",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (voiceServiceState.isRunning) "Status: RUNNING (Persistent Foreground Notification)" else "Status: STOPPED",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (voiceServiceState.isRunning) NeonGreen else TextMuted
                    )
                }

                Switch(
                    checked = voiceServiceState.isRunning,
                    onCheckedChange = {
                        val success = viewModel.toggleBackgroundAssistant()
                        if (!success) {
                            Toast.makeText(context, "Microphone permission required!", Toast.LENGTH_LONG).show()
                        } else {
                            val msg = if (voiceServiceState.isRunning) "Background Service Stopped" else "Background Service Started!"
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CyberBlack,
                        checkedTrackColor = CyberCyan,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = CyberSurface
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Wake word triggers info box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF071220))
                    .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Column {
                    Text(
                        text = "Supported Wake Words (Low-Power Loop):",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• English: \"Hey Auriya\", \"Auriya\"\n• Bangla: \"হেই অউরিয়া\", \"অউরিয়া\", \"ওরিয়া\"\n• Hindi: \"हे ओरिया\", \"ओरिया\", \"नमस्ते औरिया\"",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Hands-Free Continuous Conversation toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Hands-Free Continuous Conversation",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "Automatically listen again when AI finishes speaking",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                Switch(
                    checked = handsFreeContinuous,
                    onCheckedChange = { viewModel.setHandsFreeContinuous(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CyberBlack,
                        checkedTrackColor = CyberCyan
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Interruption handling notice
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = NeonMagenta, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Interruption Support: Speak while AI talks to immediately stop TTS.",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFFF80BF),
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. DYNAMIC LANGUAGE DETECTION & TTS
        SettingsSectionCard(title = "DYNAMIC LANGUAGE DETECTION & TTS", icon = Icons.Default.Translate) {
            Text(
                text = "Language Auto-Matching Rule Active:",
                style = MaterialTheme.typography.labelSmall,
                color = CyberCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Gemini API system instruction ensures Auriya always replies in the exact language you spoke (Bangla, English, or Hindi). TTS dynamically switches locale before speaking.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Pitch slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Female Voice Pitch (1.15x feminine tone)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(text = "%.2f".format(voicePitch), style = MaterialTheme.typography.labelSmall, color = NeonMagenta)
            }
            Slider(
                value = voicePitch,
                onValueChange = { viewModel.setVoicePitch(it) },
                valueRange = 0.8f..1.6f,
                colors = SliderDefaults.colors(thumbColor = NeonMagenta, activeTrackColor = NeonMagenta)
            )

            // Speed slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Speaking Rate", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(text = "%.2f".format(voiceRate), style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
            }
            Slider(
                value = voiceRate,
                onValueChange = { viewModel.setVoiceRate(it) },
                valueRange = 0.6f..1.4f,
                colors = SliderDefaults.colors(thumbColor = ElectricBlue, activeTrackColor = ElectricBlue)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. AI BRAIN & GEMINI MODEL
        SettingsSectionCard(title = "AI BRAIN & MODEL SELECTION", icon = Icons.Default.AutoAwesome) {
            Text(
                text = "Select Neural Model:",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))

            GeminiApiClient.AVAILABLE_MODELS.forEach { (modelId, displayName) ->
                val isSelected = selectedModel == modelId
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF00384D) else CyberSurface)
                        .border(1.dp, if (isSelected) CyberCyan else CyberBorder, RoundedCornerShape(8.dp))
                        .clickable { viewModel.setModel(modelId) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = displayName,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isSelected) CyberCyan else TextPrimary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                    if (isSelected) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Temperature Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Temperature (Creativity)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(text = "%.2f".format(temperature), style = MaterialTheme.typography.labelSmall, color = CyberCyan)
            }
            Slider(
                value = temperature,
                onValueChange = { viewModel.setTemperature(it) },
                valueRange = 0.0f..1.5f,
                colors = SliderDefaults.colors(
                    thumbColor = CyberCyan,
                    activeTrackColor = CyberCyan,
                    inactiveTrackColor = CyberSurface
                )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 4. GEMINI API KEY CONFIGURATION
        SettingsSectionCard(title = "GEMINI API CONFIGURATION", icon = Icons.Default.Key) {
            Text(
                text = "Enter your Google Gemini API key or let AI Studio inject it via Secrets:",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = { apiKeyInput = it },
                label = { Text("Gemini API Key") },
                placeholder = { Text("AIzaSy...") },
                visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    Text(
                        text = if (showApiKey) "Hide" else "Show",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        modifier = Modifier
                            .clickable { showApiKey = !showApiKey }
                            .padding(8.dp)
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CyberBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = CyberBlack,
                    unfocusedContainerColor = CyberBlack
                ),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    viewModel.setCustomApiKey(apiKeyInput.trim())
                    Toast.makeText(context, "API Key updated", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Save Key", color = CyberBlack, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 5. AURIYA PERSONALITY MODES
        SettingsSectionCard(title = "AURIYA PERSONALITY MODES", icon = Icons.Default.Psychology) {
            PersonalityMode.values().forEach { mode ->
                val isSelected = currentPersonality == mode
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF26123D) else CyberSurface)
                        .border(1.dp, if (isSelected) NeonPurple else CyberBorder, RoundedCornerShape(8.dp))
                        .clickable { viewModel.setPersonality(mode) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = mode.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = if (isSelected) NeonPurple else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = mode.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    if (isSelected) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = NeonPurple)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 6. ACCESSIBILITY & SCREEN INTERACTION
        SettingsSectionCard(title = "SCREEN INTERACTION & ACCESSIBILITY", icon = Icons.Default.AccessibilityNew) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Auriya Accessibility Service", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Text(
                        text = if (isAccessibilityActive) "Service Status: ACTIVE (Screen Automation Enabled)" else "Service Status: INACTIVE (Enable in Android Settings)",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isAccessibilityActive) NeonGreen else Color(0xFFFFB300)
                    )
                }

                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                ) {
                    Text("Configure", color = CyberBlack)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 7. TERMUX AUTOMATIC BUILD SYSTEM
        SettingsSectionCard(title = "TERMUX BUILD & SOURCE PACKAGER", icon = Icons.Default.Terminal) {
            Text(
                text = "Build this app in Termux with root build.sh script:",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF030509))
                    .padding(10.dp)
            ) {
                Text(
                    text = "bash build.sh\nOutput: AURIYA-AI.apk & AURIYA-AI-Full-Source.zip",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = NeonGreen
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 8. ABOUT AURIYA AI
        SettingsSectionCard(title = "ABOUT AURIYA AI", icon = Icons.Default.Info) {
            Text(
                text = "AURIYA AI — Next-Generation Personal AI Assistant",
                style = MaterialTheme.typography.titleSmall,
                color = CyberCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Tagline: \"Your World. Your Intelligence. Your AURIYA.\"",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Architecture: Jetpack Compose, Room SQLite, Android SpeechRecognizer, Foreground Voice Service, Dynamic TTS, Gemini API multi-model reasoning, Accessibility Automation, Termux build suite.",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun SettingsSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberDark),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(CyberBorder, CyberBorderPurple))
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}
