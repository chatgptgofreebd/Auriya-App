package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.AssistantStatus
import com.example.R
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AnimatedAuriyaCore(
    status: AssistantStatus,
    audioLevel: Float = 0f,
    size: Dp = 220.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "auriya_core_infinite")

    // Rotation speeds based on status
    val rotationSpeed = when (status) {
        AssistantStatus.THINKING -> 2000
        AssistantStatus.LISTENING -> 3500
        AssistantStatus.SPEAKING -> 4000
        AssistantStatus.IDLE -> 8000
    }

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = rotationSpeed, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val counterRotationAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = (rotationSpeed * 1.5).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = if (status == AssistantStatus.LISTENING) 1.08f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (status == AssistantStatus.LISTENING) 600 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val effectiveScale = pulseScale + (audioLevel * 0.12f)

    Box(
        modifier = Modifier
            .size(size)
            .scale(effectiveScale)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // Outer glowing canvas rings
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .rotate(rotationAngle)
        ) {
            val center = Offset(this.size.width / 2, this.size.height / 2)
            val maxRadius = this.size.width / 2

            // Outer segmented cyan ring
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(CyberCyan, NeonPurple, ElectricBlue, CyberCyan)
                ),
                radius = maxRadius - 6.dp.toPx(),
                center = center,
                style = Stroke(width = 2.5.dp.toPx())
            )

            // Orbital nodes
            for (i in 0 until 4) {
                val angle = Math.toRadians((i * 90.0) + rotationAngle.toDouble())
                val x = center.x + (maxRadius - 6.dp.toPx()) * cos(angle).toFloat()
                val y = center.y + (maxRadius - 6.dp.toPx()) * sin(angle).toFloat()
                drawCircle(
                    color = CyberCyan,
                    radius = 4.dp.toPx(),
                    center = Offset(x, y)
                )
            }
        }

        // Counter rotating inner neon ring
        Canvas(
            modifier = Modifier
                .size(size - 32.dp)
                .rotate(counterRotationAngle)
        ) {
            val center = Offset(this.size.width / 2, this.size.height / 2)
            val radius = this.size.width / 2

            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(NeonMagenta, CyberCyan, NeonPurple, NeonMagenta)
                ),
                radius = radius - 4.dp.toPx(),
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Center AURIYA Holographic AI Avatar
        Box(
            modifier = Modifier
                .size(size - 64.dp)
                .shadow(
                    elevation = 20.dp,
                    shape = CircleShape,
                    spotColor = if (status == AssistantStatus.LISTENING) CyberCyan else NeonPurple,
                    ambientColor = CyberCyan
                )
                .clip(CircleShape)
                .border(
                    width = 2.dp,
                    brush = Brush.radialGradient(
                        colors = listOf(CyberCyan, NeonPurple, Color.Transparent)
                    ),
                    shape = CircleShape
                )
                .background(Color(0xFF090D1A)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.auriya_avatar),
                contentDescription = "Auriya AI Core Avatar",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
