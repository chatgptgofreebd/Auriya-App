package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        MemoryEntity::class,
        ConversationEntity::class,
        AutomationEntity::class,
        CodeProjectEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun conversationDao(): ConversationDao
    abstract fun automationDao(): AutomationDao
    abstract fun codeProjectDao(): CodeProjectDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "auriya_ai_database"
                )
                    .fallbackToDestructiveMigration(true)
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(db: AppDatabase) {
                // Populate default automations
                val defaultAutomations = listOf(
                    AutomationEntity(
                        title = "Open YouTube",
                        triggerPhrase = "open youtube",
                        actionType = "LAUNCH_YOUTUBE",
                        actionParam = ""
                    ),
                    AutomationEntity(
                        title = "Play Music",
                        triggerPhrase = "play my music",
                        actionType = "PLAY_MUSIC",
                        actionParam = "lofi chill coding music"
                    ),
                    AutomationEntity(
                        title = "Check Battery",
                        triggerPhrase = "battery status",
                        actionType = "BATTERY_STATUS",
                        actionParam = ""
                    ),
                    AutomationEntity(
                        title = "Open Camera",
                        triggerPhrase = "open camera",
                        actionType = "OPEN_CAMERA",
                        actionParam = ""
                    ),
                    AutomationEntity(
                        title = "Open Code Studio",
                        triggerPhrase = "start coding",
                        actionType = "OPEN_CODING_STUDIO",
                        actionParam = ""
                    ),
                    AutomationEntity(
                        title = "Open Settings",
                        triggerPhrase = "open settings",
                        actionType = "OPEN_SETTINGS",
                        actionParam = ""
                    )
                )
                defaultAutomations.forEach { db.automationDao().insertAutomation(it) }

                // Populate starter code project
                db.codeProjectDao().insertProject(
                    CodeProjectEntity(
                        name = "CyberDashboard.html",
                        language = "HTML",
                        codeContent = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Auriya Hologram</title>
  <style>
    body { margin: 0; background: #05070d; color: #00f0ff; display: flex; align-items: center; justify-content: center; height: 100vh; font-family: monospace; }
    .core { width: 140px; height: 140px; border-radius: 50%; border: 3px solid #00f0ff; box-shadow: 0 0 20px #00f0ff; animation: pulse 2s infinite alternate; }
    @keyframes pulse { from { transform: scale(0.9); } to { transform: scale(1.1); } }
  </style>
</head>
<body>
  <div style="text-align:center;">
    <div class="core"></div>
    <h2>AURIYA AI CORE</h2>
    <p>Status: ONLINE</p>
  </div>
</body>
</html>"""
                    )
                )

                // Populate initial greeting memory
                db.memoryDao().insertMemory(
                    MemoryEntity(
                        key = "Assistant Identity",
                        value = "Female personal AI named Auriya. Caring, friendly, intelligent companion.",
                        category = "Identity"
                    )
                )
            }
        }
    }
}
