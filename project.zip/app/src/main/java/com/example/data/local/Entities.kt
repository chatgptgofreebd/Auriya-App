package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val value: String,
    val category: String = "General",
    val timestamp: Long = System.currentTimeMillis(),
    val isUserApproved: Boolean = true
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // USER, AURIYA, SYSTEM
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionTag: String? = null,
    val imageUri: String? = null
)

@Entity(tableName = "automations")
data class AutomationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val triggerPhrase: String,
    val actionType: String,
    val actionParam: String,
    val isEnabled: Boolean = true
)

@Entity(tableName = "code_projects")
data class CodeProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val language: String,
    val codeContent: String,
    val lastUpdated: Long = System.currentTimeMillis()
)
