#!/bin/bash
# ==============================================================================
# AURIYA AI — APK Installation Script
# ==============================================================================

set -e

APK_PATH="output/AURIYA-AI.apk"

if [ ! -f "$APK_PATH" ]; then
    echo "[!] APK file not found at $APK_PATH"
    echo "[*] Please build the application first using: bash build.sh"
    exit 1
fi

echo "[*] Found APK: $APK_PATH"

if command -v adb >/dev/null 2>&1; then
    echo "[*] Installing AURIYA AI via ADB..."
    adb install -r "$APK_PATH"
    echo "[✓] Successfully installed AURIYA AI!"
elif command -v termux-open >/dev/null 2>&1; then
    echo "[*] Opening APK package installer via Termux..."
    termux-open "$APK_PATH"
else
    echo "[✓] APK is located at: $(pwd)/$APK_PATH"
    echo "    Transfer or open this file with your Android package manager."
fi
