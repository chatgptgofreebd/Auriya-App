# AURIYA AI — Next-Generation Personal AI Assistant

> **Tagline:** *"Your World. Your Intelligence. Your AURIYA."*

AURIYA is a next-generation personal female AI assistant for Android, combining high-efficiency intelligence inspired by JARVIS with an empathetic, supportive personality, tactical device control, real-time voice interaction, and developer coding tools.

---

## 🌟 Key Features

### 1. AURIYA AI Brain & Intelligence
- **Google Gemini API Multi-Model Architecture**: Seamlessly supports `gemini-2.5-flash`, `gemini-2.5-pro`, `gemini-1.5-flash`, and `gemini-1.5-pro`.
- **Intelligent Offline Fallback**: Functions continuously even without an active internet connection or API key.
- **5 Personality Modes**:
  - *Empathetic Assistant*: Warm, supportive, conversational.
  - *JARVIS Tactical Core*: Direct, executive, high-efficiency data briefing.
  - *Genius Code Master*: Deep technical architecture & debugging insight.
  - *Polyglot Cultural Bridge*: Natural Bangla (বাংলা), English, Hindi (हिंदी), and Banglish.
  - *Creative Companion*: Inspiring writing, ideation, and design.

### 2. Android Device Control & System Telemetry
- Launch YouTube, search specific videos, and play music.
- Live device telemetry: real-time battery percentage, charging state, power source, and network connectivity.
- Launch Camera, Photos/Gallery, Google Maps, and System Settings (Wi-Fi, Bluetooth, Sound).
- Create Alarms and Calendar Reminders via standard Android system intents.

### 3. Voice Engine
- Real-time speech-to-text recognition in **Bangla**, **English**, and **Hindi**.
- Natural female text-to-speech with customizable pitch and speech rate.
- Animated audio waveform visualizer and orbital holographic AI core.

### 4. Screen Interaction & Accessibility Service
- Built-in `AuriyaAccessibilityService` supporting authorized screen element detection, gestures (Back, Home, Notifications), and page scrolling.

### 5. Coding & Developer Studio
- Multi-language code editor: HTML, Kotlin, Python, JavaScript, PHP, Java, and Bash/Termux.
- In-app AI code generator.
- Single-tap **Export as ZIP** archive directly to device storage.
- Interactive Termux commands viewer and instructions.

### 6. Neural Memory System
- Local Room SQLite database for user-approved preferences, facts, and guidelines.
- Complete user sovereignty: view, edit, search, and delete saved memories anytime.

### 7. Custom Automations Engine
- Configure voice phrases to trigger specific Android actions (e.g. "when I say open YouTube, launch YouTube").

---

## 🚀 Building with Termux

You can build this entire Android project directly on your Android phone using **Termux**!

### Quick Start:
```bash
# 1. Setup environment & install JDK 17
bash setup.sh

# 2. Build the APK & package full source code
bash build.sh

# 3. Install the APK on your device
bash install.sh
```

### Outputs Generated:
- `output/AURIYA-AI.apk`: Production debug APK ready for installation.
- `output/AURIYA-AI-Full-Source.zip`: Complete packaged workspace archive.

---

## 🛠️ Troubleshooting

| Issue | Solution |
|---|---|
| `Java not found` | Run `pkg install openjdk-17 -y` in Termux or `sudo apt install openjdk-17-jdk` on Linux. |
| `API Key not configured` | Add your Gemini API key in **Settings > Gemini API Configuration**, or set `GEMINI_API_KEY` in the AI Studio Secrets panel. |
| `Microphone permission denied` | Grant microphone permission when prompted or in Android App Settings. |
| `Accessibility not active` | Tap **Configure** in **Settings > Screen Interaction** to enable the Auriya Accessibility Service. |
